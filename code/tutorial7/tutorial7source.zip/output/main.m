close all
clear all
loadAndPlot("fs", "Mean Squared Error", 0);
loadAndPlot("solnFounds", "Probability of Solution", 1);
loadAndPlot("failures1", "Probability $g_1(a(D))>0$", 1);
loadAndPlot("failures2", "Probability $g_2(a(D))>0$", 1);